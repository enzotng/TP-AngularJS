function sayHello($scope) {
  $scope.name = { text: "Your Name" };
}
